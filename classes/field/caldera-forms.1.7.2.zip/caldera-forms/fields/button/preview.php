<div class="preview-caldera-config-group">
	{{#if config/label_space}}<lable class="control-label">&nbsp;</lable>{{/if}}
	<button type="{{config/type}}" class="button" disabled="disabled">{{label}}</button>
</div>