<div class="caldera-config-group">
	<label for="{{_id}}_value">
        <?php esc_html_e('Value', 'caldera-forms'); ?>
    </label>
	<div class="caldera-config-field">
		<input id="{{_id}}_value" type="text" class="block-input field-config magic-tag-enabled" name="{{_name}}[default]" value="{{default}}">
	</div>
</div>