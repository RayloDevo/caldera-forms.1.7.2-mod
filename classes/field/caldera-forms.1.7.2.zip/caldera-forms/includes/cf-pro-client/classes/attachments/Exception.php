<?php


namespace calderawp\calderaforms\pro\attachments;


/**
 * Class Exception
 * @package calderawp\calderaforms\pro\attachments
 */
class Exception  extends \Exception{

}